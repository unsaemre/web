$(document).ready(function(){
    $(".modal_notice").click(function(){
      $(".modal").show();
    });
  });